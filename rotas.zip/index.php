
<?php
// Arquivo index responsável pela inicialização do sistema

//require_once 'sistema/configuracao.php';
//include_once 'sistema/Nucleo/helpers.php';
//include './sistema/Nucleo/Mensagem.php';
//include './sistema/Nucleo/Controlador.php';
//use sistema\Modelo\PostModelo;
require 'vendor/autoload.php';



require 'rotas.php';
